
export enum BadgeLevel {
  BRONZE = 'Bronze',
  SILVER = 'Silver',
  GOLD = 'Gold'
}

export interface ReviewAnalysis {
  roi: string;
  useCase: string;
}

export interface ValidationReport {
  strengths: string[];
  risks: string[];
  marketReadiness: string;
  recommendation: string;
}

export interface Review {
  id: string;
  startupId: string;
  user: string;
  text: string;
  rating: number;
  analysis?: ReviewAnalysis;
  createdAt: string;
}

export interface Startup {
  id: string;
  name: string;
  category: string;
  arrRange: string;
  description: string;
  tagline: string;
  summary: string;
  website: string;
  upvotes: number;
  score: number;
  badge: BadgeLevel;
  reviews: Review[];
  validationReport?: ValidationReport;
  createdAt: string;
}

export interface MatchResult {
  startupId: string;
  name: string;
  reason: string;
  score: number;
}

export interface FilterCriteria {
  searchQuery: string;
  categories: string[];
  arrRanges: string[];
  badges: string[];
}

export interface User {
  id: string;
  email: string;
  name: string;
  number: string;
  organisation: string;
  dob: string;
  password?: string; // Only used for verification during mock login
  accessKey: string;
  role: 'Enterprise' | 'Founder' | 'Investor';
}
