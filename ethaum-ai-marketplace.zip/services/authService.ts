
import { User } from '../types';

const USERS_STORAGE_KEY = 'ethaum_users_db';
const SESSION_STORAGE_KEY = 'ethaum_active_session';

export const authService = {
  getUsers: (): User[] => {
    const data = localStorage.getItem(USERS_STORAGE_KEY);
    return data ? JSON.parse(data) : [];
  },

  register: async (userData: Omit<User, 'id' | 'accessKey' | 'role'>): Promise<string> => {
    await new Promise(resolve => setTimeout(resolve, 1000));
    const users = authService.getUsers();

    if (users.find(u => u.email === userData.email)) {
      throw new Error("Enterprise Email already registered.");
    }

    // Generate a unique access key for this enterprise
    const accessKey = `ETH-${Math.random().toString(36).substr(2, 6).toUpperCase()}`;

    const newUser: User = {
      ...userData,
      id: Math.random().toString(36).substr(2, 9),
      accessKey,
      role: 'Enterprise'
    };

    users.push(newUser);
    localStorage.setItem(USERS_STORAGE_KEY, JSON.stringify(users));
    return accessKey;
  },

  login: async (email: string, password: string, accessKey: string): Promise<User> => {
    await new Promise(resolve => setTimeout(resolve, 1200));
    const users = authService.getUsers();
    
    const user = users.find(u => 
      u.email === email && 
      u.password === password && 
      u.accessKey === accessKey
    );

    if (!user) {
      throw new Error("Invalid credentials or Access Key. Please check details.");
    }

    // Store session without the password
    const { password: _, ...sessionUser } = user;
    localStorage.setItem(SESSION_STORAGE_KEY, JSON.stringify(sessionUser));
    return sessionUser as User;
  },

  logout: () => {
    localStorage.removeItem(SESSION_STORAGE_KEY);
  },

  getCurrentUser: (): User | null => {
    const session = localStorage.getItem(SESSION_STORAGE_KEY);
    return session ? JSON.parse(session) : null;
  },

  isAuthenticated: (): boolean => {
    return localStorage.getItem(SESSION_STORAGE_KEY) !== null;
  }
};
