
import { GoogleGenAI, Type, Modality } from "@google/genai";
import { Startup, BadgeLevel, ReviewAnalysis, MatchResult, ValidationReport } from '../types';

export const geminiService = {
  /**
   * Generates tagline and summary for a new startup launch
   */
  generateLaunchAssets: async (name: string, category: string, description: string) => {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `Startup Name: ${name}\nCategory: ${category}\nDescription: ${description}`,
      config: {
        systemInstruction: "You are an expert tech journalist and copywriter. Generate a catchy 1-line tagline and a 3-sentence professional executive summary for the following startup. Return as JSON.",
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            tagline: { type: Type.STRING },
            summary: { type: Type.STRING }
          },
          required: ["tagline", "summary"]
        }
      }
    });
    return JSON.parse(response.text || "{}");
  },

  /**
   * Generates a deep-dive AI validation report
   */
  generateValidationReport: async (startup: Startup): Promise<ValidationReport> => {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    const response = await ai.models.generateContent({
      model: 'gemini-3-pro-preview',
      contents: `Analyze this startup: 
        Name: ${startup.name}
        Category: ${startup.category}
        ARR: ${startup.arrRange}
        Description: ${startup.description}
        Reviews: ${JSON.stringify(startup.reviews.map(r => r.text))}`,
      config: {
        systemInstruction: "You are a senior Gartner analyst and VC partner. Provide a structured validation report covering strengths, risks, market readiness, and a strategic recommendation. Return as JSON.",
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            strengths: { type: Type.ARRAY, items: { type: Type.STRING } },
            risks: { type: Type.ARRAY, items: { type: Type.STRING } },
            marketReadiness: { type: Type.STRING },
            recommendation: { type: Type.STRING }
          },
          required: ["strengths", "risks", "marketReadiness", "recommendation"]
        }
      }
    });
    return JSON.parse(response.text || "{}");
  },

  /**
   * Analyzes a user review to extract ROI and use-case signals
   */
  analyzeReview: async (reviewText: string): Promise<ReviewAnalysis> => {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `Review: ${reviewText}`,
      config: {
        systemInstruction: "Analyze the following user review. Extract the primary ROI (Return on Investment - either qualitative or quantitative) and the core use case mentioned. Return as JSON.",
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            roi: { type: Type.STRING },
            useCase: { type: Type.STRING }
          },
          required: ["roi", "useCase"]
        }
      }
    });
    return JSON.parse(response.text || "{}");
  },

  /**
   * Calculates a Gartner-style credibility score
   */
  calculateCredibilityScore: async (startup: Startup): Promise<{ score: number, badge: BadgeLevel }> => {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    const avgRating = startup.reviews.length > 0 
      ? startup.reviews.reduce((acc, r) => acc + r.rating, 0) / startup.reviews.length 
      : 0;

    const statsContext = `
      Upvotes: ${startup.upvotes}
      Average Rating: ${avgRating}
      ARR Range: ${startup.arrRange}
      Review Count: ${startup.reviews.length}
      Description: ${startup.description}
    `;

    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: statsContext,
      config: {
        systemInstruction: `Calculate a credibility score from 0 to 100 based on the provided metrics. Consider engagement (upvotes/reviews), customer satisfaction (rating), and business maturity (ARR). 
        Badge levels:
        0-40: Bronze
        41-75: Silver
        76-100: Gold
        Return the score and corresponding badge as JSON.`,
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            score: { type: Type.NUMBER },
            badge: { type: Type.STRING }
          },
          required: ["score", "badge"]
        }
      }
    });

    const result = JSON.parse(response.text || '{"score": 0, "badge": "Bronze"}');
    return {
      score: Math.min(100, Math.max(0, result.score)),
      badge: result.badge as BadgeLevel
    };
  },

  /**
   * Matches enterprise needs with top startups
   */
  matchStartups: async (needs: string, startups: Startup[]): Promise<MatchResult[]> => {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    const startupList = startups.map(s => ({
      id: s.id,
      name: s.name,
      category: s.category,
      summary: s.summary
    }));

    const response = await ai.models.generateContent({
      model: 'gemini-3-pro-preview',
      contents: `Enterprise Need: ${needs}\nAvailable Startups: ${JSON.stringify(startupList)}`,
      config: {
        systemInstruction: "Act as an Enterprise AI Consultant. Match the top 3 relevant startups from the provided list based on the enterprise needs. For each match, provide a score (0-100) and a brief reasoning string. Return as a JSON array.",
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              startupId: { type: Type.STRING },
              name: { type: Type.STRING },
              score: { type: Type.NUMBER },
              reason: { type: Type.STRING }
            },
            required: ["startupId", "name", "score", "reason"]
          }
        }
      }
    });

    return JSON.parse(response.text || "[]");
  },

  /**
   * Creates a chat session for the assistant with Thinking Budget
   */
  createAssistantChat: (startupContext: string) => {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    return ai.chats.create({
      model: 'gemini-3-pro-preview',
      config: {
        systemInstruction: `You are the EthAum AI Marketplace Assistant. You have access to the following context about startups currently in the marketplace: ${startupContext}. 
        Answer user questions about startups, enterprise matches, and marketplace trends. 
        Be concise, professional, and data-driven. 
        When asked complex queries about ROI or competitive landscape, use your thinking capabilities to provide deep insights.`,
        thinkingConfig: { thinkingBudget: 32768 }
      },
    });
  },

  /**
   * Generates TTS audio for a given text
   */
  generateSpeech: async (text: string) => {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    try {
      const response = await ai.models.generateContent({
        model: "gemini-2.5-flash-preview-tts",
        contents: [{ parts: [{ text: `Please read this clearly: ${text}` }] }],
        config: {
          responseModalities: [Modality.AUDIO],
          speechConfig: {
            voiceConfig: {
              prebuiltVoiceConfig: { voiceName: 'Kore' },
            },
          },
        },
      });
      return response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
    } catch (err) {
      console.error("Gemini TTS API Error:", err);
      throw err;
    }
  }
};

// Audio Utilities
export const audioUtils = {
  decode: (base64: string) => {
    const binaryString = atob(base64);
    const len = binaryString.length;
    const bytes = new Uint8Array(len);
    for (let i = 0; i < len; i++) {
      bytes[i] = binaryString.charCodeAt(i);
    }
    return bytes;
  },
  decodeAudioData: async (
    data: Uint8Array,
    ctx: AudioContext,
    sampleRate: number,
    numChannels: number,
  ): Promise<AudioBuffer> => {
    const dataInt16 = new Int16Array(data.buffer);
    const frameCount = dataInt16.length / numChannels;
    const buffer = ctx.createBuffer(numChannels, frameCount, sampleRate);

    for (let channel = 0; channel < numChannels; channel++) {
      const channelData = buffer.getChannelData(channel);
      for (let i = 0; i < frameCount; i++) {
        channelData[i] = dataInt16[i * numChannels + channel] / 32768.0;
      }
    }
    return buffer;
  }
};
