
import { Startup, Review, BadgeLevel, FilterCriteria } from '../types';

const COLLECTION_NAME = 'startups';

/**
 * Mock MongoDB Client for MVP
 * Mimics MongoDB Atlas App Services (Realm) Web SDK interface
 */
class MongoSimulator {
  private async getCollection(): Promise<Startup[]> {
    const data = localStorage.getItem(COLLECTION_NAME);
    return data ? JSON.parse(data) : [];
  }

  private async saveCollection(data: Startup[]): Promise<void> {
    localStorage.setItem(COLLECTION_NAME, JSON.stringify(data));
  }

  // Simulates MongoDB find()
  async find(query: any = {}): Promise<Startup[]> {
    await new Promise(r => setTimeout(r, 400)); // Simulate network lag
    let startups = await this.getCollection();
    
    // Simple filter simulation
    if (query.category) startups = startups.filter(s => s.category === query.category);
    if (query.id) startups = startups.filter(s => s.id === query.id);
    
    return startups;
  }

  // Simulates MongoDB findOne()
  async findOne(query: { id: string }): Promise<Startup | null> {
    await new Promise(r => setTimeout(r, 200));
    const startups = await this.getCollection();
    return startups.find(s => s.id === query.id) || null;
  }

  // Simulates MongoDB insertOne()
  async insertOne(doc: Startup): Promise<void> {
    await new Promise(r => setTimeout(r, 600));
    const startups = await this.getCollection();
    startups.push(doc);
    await this.saveCollection(startups);
  }

  // Simulates MongoDB updateOne()
  async updateOne(filter: { id: string }, update: Partial<Startup>): Promise<void> {
    await new Promise(r => setTimeout(r, 300));
    const startups = await this.getCollection();
    const index = startups.findIndex(s => s.id === filter.id);
    if (index !== -1) {
      startups[index] = { ...startups[index], ...update };
      await this.saveCollection(startups);
    }
  }
}

const db = new MongoSimulator();

export const storageService = {
  // Database persists to local storage but interface is fully async
  saveStartup: async (startup: Startup) => {
    await db.insertOne(startup);
  },

  getAllStartups: async (): Promise<Startup[]> => {
    return await db.find();
  },

  getTopLaunchId: async (): Promise<string | null> => {
    const startups = await db.find();
    const weekAgo = new Date();
    weekAgo.setDate(weekAgo.getDate() - 7);

    const recentStartups = startups.filter(s => new Date(s.createdAt) >= weekAgo);
    if (recentStartups.length === 0) return null;

    return recentStartups.reduce((prev, current) => 
      (prev.upvotes > current.upvotes) ? prev : current
    ).id;
  },

  queryStartups: async (filters: FilterCriteria, sortBy: 'trending' | 'newest' = 'trending'): Promise<Startup[]> => {
    let startups = await db.find();

    if (filters.searchQuery) {
      const q = filters.searchQuery.toLowerCase();
      startups = startups.filter(s => 
        s.name.toLowerCase().includes(q) || 
        s.tagline.toLowerCase().includes(q) || 
        s.category.toLowerCase().includes(q)
      );
    }

    if (filters.categories.length > 0) {
      startups = startups.filter(s => filters.categories.includes(s.category));
    }

    if (filters.arrRanges.length > 0) {
      startups = startups.filter(s => filters.arrRanges.includes(s.arrRange));
    }

    if (filters.badges.length > 0) {
      startups = startups.filter(s => filters.badges.includes(s.badge as any));
    }

    if (sortBy === 'trending') {
      return startups.sort((a, b) => b.upvotes - a.upvotes);
    } else {
      return startups.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
    }
  },

  getStartupById: async (id: string): Promise<Startup | null> => {
    return await db.findOne({ id });
  },

  updateStartup: async (updated: Startup) => {
    await db.updateOne({ id: updated.id }, updated);
  },

  addReview: async (startupId: string, review: Review) => {
    const startup = await db.findOne({ id: startupId });
    if (startup) {
      const updatedReviews = [...startup.reviews, review];
      await db.updateOne({ id: startupId }, { reviews: updatedReviews });
    }
  },

  upvoteStartup: async (id: string) => {
    const startup = await db.findOne({ id });
    if (startup) {
      await db.updateOne({ id }, { upvotes: startup.upvotes + 1 });
    }
  }
};
