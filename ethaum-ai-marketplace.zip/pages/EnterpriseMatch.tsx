
import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { geminiService } from '../services/geminiService';
import { storageService } from '../services/storageService';
import { MatchResult } from '../types';

const EnterpriseMatch: React.FC = () => {
  const [needs, setNeeds] = useState('');
  const [loading, setLoading] = useState(false);
  const [matches, setMatches] = useState<MatchResult[]>([]);

  const handleMatch = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!needs.trim()) return;

    setLoading(true);
    try {
      // Step 1: Query all startups from the "DB"
      const startups = await storageService.getAllStartups();
      
      if (startups.length === 0) {
        alert("The database is currently empty. Please launch some startups first!");
        return;
      }

      // Step 2: Perform AI comparison logic via Gemini
      const results = await geminiService.matchStartups(needs, startups);
      setMatches(results);
    } catch (error) {
      console.error('Match error:', error);
      alert('Error querying the match engine. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-16">
      <div className="text-center mb-12">
        <h1 className="text-5xl font-black text-gray-900 mb-4 tracking-tight">Enterprise Match Engine</h1>
        <p className="text-lg text-gray-600 font-medium">Connect your specific operational needs with our database of verified AI ventures.</p>
      </div>

      <form onSubmit={handleMatch} className="mb-12">
        <div className="bg-white p-8 rounded-[2rem] shadow-2xl shadow-blue-900/5 border border-gray-100">
          <label className="text-[10px] font-black uppercase tracking-widest text-gray-400 mb-3 block">Operational Requirement</label>
          <textarea
            required
            rows={5}
            className="w-full p-4 bg-gray-50 border border-gray-100 rounded-2xl outline-none focus:ring-4 focus:ring-blue-500/10 focus:bg-white mb-6 text-lg font-medium text-black placeholder:text-gray-300 transition-all"
            placeholder="Describe a business challenge... (e.g., 'We need a predictive analytics layer for our supply chain that works with SAP and legacy SQL data...')"
            value={needs}
            onChange={e => setNeeds(e.target.value)}
          />
          <button
            disabled={loading}
            className={`w-full py-5 rounded-2xl font-black text-lg text-white shadow-xl transition-all flex items-center justify-center space-x-2 ${
              loading ? 'bg-blue-400 cursor-not-allowed' : 'bg-blue-600 hover:bg-blue-700 shadow-blue-500/20 active:scale-95'
            }`}
          >
            {loading ? (
              <>
                <div className="w-5 h-5 border-2 border-white border-t-transparent animate-spin rounded-full"></div>
                <span>Scanning Database...</span>
              </>
            ) : (
              <span>Compute Match results</span>
            )}
          </button>
        </div>
      </form>

      {matches.length > 0 && (
        <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
          <div className="flex items-center justify-between border-b border-gray-100 pb-4">
            <h2 className="text-2xl font-black text-gray-900">Ranked Match Results</h2>
            <span className="text-xs font-bold text-gray-400 uppercase tracking-widest">Powered by Gemini Matchmaker</span>
          </div>
          {matches.map((match, idx) => (
            <div key={match.startupId} className="bg-white p-8 rounded-3xl border border-gray-100 shadow-sm hover:shadow-xl transition-all group relative overflow-hidden">
              <div className="absolute top-0 right-0 p-4">
                 <div className="bg-blue-50 text-blue-600 font-black px-4 py-2 rounded-2xl text-sm shadow-sm border border-blue-100">
                  {match.score}% Accuracy
                </div>
              </div>
              
              <div className="flex items-center space-x-4 mb-6">
                <span className="w-10 h-10 bg-gray-900 text-white flex items-center justify-center rounded-2xl font-black text-lg shadow-lg">#{idx + 1}</span>
                <h3 className="text-2xl font-black text-gray-900 group-hover:text-blue-600 transition-colors">{match.name}</h3>
              </div>
              
              <div className="bg-blue-50/30 p-6 rounded-2xl border border-blue-50 mb-6">
                <p className="text-gray-700 font-medium leading-relaxed italic">"{match.reason}"</p>
              </div>
              
              <Link 
                to={`/startup/${match.startupId}`}
                className="bg-gray-50 text-gray-900 px-6 py-3 rounded-xl font-black text-xs uppercase tracking-widest hover:bg-blue-600 hover:text-white transition-all inline-flex items-center"
              >
                Inspect Venture Document
                <svg className="w-4 h-4 ml-2" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M14 5l7 7m0 0l-7 7m7-7H3"></path></svg>
              </Link>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default EnterpriseMatch;
