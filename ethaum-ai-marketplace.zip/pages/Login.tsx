
import React, { useState, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { authService } from '../services/authService';
import EthAumLogo from '../components/EthAumLogo';

const Login: React.FC = () => {
  const [isSignup, setIsSignup] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');
  const [successKey, setSuccessKey] = useState<string | null>(null);

  // Form States
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [accessKey, setAccessKey] = useState('');
  const [ownerName, setOwnerName] = useState('');
  const [ownerNumber, setOwnerNumber] = useState('');
  const [orgName, setOrgName] = useState('');
  const [dob, setDob] = useState('');

  const navigate = useNavigate();
  const location = useLocation();

  useEffect(() => {
    if (authService.isAuthenticated()) {
      navigate('/');
    }
  }, [navigate]);

  const calculateAge = (dateString: string) => {
    const today = new Date();
    const birthDate = new Date(dateString);
    let age = today.getFullYear() - birthDate.getFullYear();
    const m = today.getMonth() - birthDate.getMonth();
    if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) {
      age--;
    }
    return age;
  };

  const handleAction = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setError('');

    try {
      if (isSignup) {
        // Validation for Age
        if (calculateAge(dob) < 18) {
          throw new Error("Enterprise Owner must be at least 18 years of age.");
        }

        const generatedKey = await authService.register({
          name: ownerName,
          email,
          number: ownerNumber,
          organisation: orgName,
          dob,
          password
        });
        setSuccessKey(generatedKey);
        setIsSignup(false);
        // Reset signup fields but keep email for convenience
        setPassword('');
        setOwnerName('');
        setOwnerNumber('');
        setOrgName('');
        setDob('');
      } else {
        await authService.login(email, password, accessKey);
        const origin = (location.state as any)?.from?.pathname || '/';
        navigate(origin);
      }
    } catch (err: any) {
      setError(err.message || 'An unexpected error occurred during verification.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center px-4 py-12 relative overflow-y-auto">
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-blue-500/5 rounded-full blur-[120px] pointer-events-none"></div>
      
      <div className="w-full max-w-xl z-10">
        <div className="text-center mb-10">
          <EthAumLogo className="h-20 mx-auto mb-6" />
          <h1 className="text-3xl font-black text-gray-900 tracking-tight">
            {isSignup ? 'Enterprise Registration' : 'Identity Verification'}
          </h1>
          <p className="text-gray-500 font-medium mt-2">
            {isSignup ? 'Establish your corporate identity' : 'Authorized Enterprise Access'}
          </p>
        </div>

        {successKey && (
          <div className="mb-8 p-6 bg-emerald-50 border border-emerald-100 rounded-[2rem] text-center animate-in zoom-in duration-300 shadow-xl shadow-emerald-500/10">
            <p className="text-emerald-800 font-black text-lg mb-2">Registration Successful!</p>
            <p className="text-emerald-600 text-sm font-medium mb-4">Your unique Enterprise Access Key is:</p>
            <div className="bg-white px-6 py-4 rounded-xl border border-emerald-200 font-mono text-2xl font-black text-emerald-900 tracking-widest mb-4">
              {successKey}
            </div>
            <p className="text-emerald-500 text-[10px] font-black uppercase tracking-widest">Store this safely. It is required for all future logins.</p>
            <button 
              onClick={() => setSuccessKey(null)}
              className="mt-4 text-emerald-700 font-bold text-xs underline"
            >
              Dismiss
            </button>
          </div>
        )}

        <div className="glass-card rounded-[2.5rem] p-8 md:p-12 shadow-2xl shadow-blue-900/10 border border-white/50">
          <form onSubmit={handleAction} className="space-y-5">
            {error && (
              <div className="bg-rose-50 border border-rose-100 text-rose-600 px-4 py-3 rounded-xl text-xs font-bold text-center">
                {error}
              </div>
            )}

            {isSignup ? (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-1">
                  <label className="text-[10px] font-black uppercase tracking-widest text-gray-400 ml-1">Owner Name</label>
                  <input
                    required
                    type="text"
                    placeholder="Full legal name"
                    className="w-full px-4 py-3 bg-gray-50/50 border border-gray-100 rounded-xl outline-none focus:ring-4 focus:ring-blue-500/10 focus:bg-white transition-all font-medium text-sm"
                    value={ownerName}
                    onChange={(e) => setOwnerName(e.target.value)}
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-[10px] font-black uppercase tracking-widest text-gray-400 ml-1">Owner Contact</label>
                  <input
                    required
                    type="tel"
                    placeholder="+1 (555) 000-0000"
                    className="w-full px-4 py-3 bg-gray-50/50 border border-gray-100 rounded-xl outline-none focus:ring-4 focus:ring-blue-500/10 focus:bg-white transition-all font-medium text-sm"
                    value={ownerNumber}
                    onChange={(e) => setOwnerNumber(e.target.value)}
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-[10px] font-black uppercase tracking-widest text-gray-400 ml-1">Organisation</label>
                  <input
                    required
                    type="text"
                    placeholder="Company name"
                    className="w-full px-4 py-3 bg-gray-50/50 border border-gray-100 rounded-xl outline-none focus:ring-4 focus:ring-blue-500/10 focus:bg-white transition-all font-medium text-sm"
                    value={orgName}
                    onChange={(e) => setOrgName(e.target.value)}
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-[10px] font-black uppercase tracking-widest text-gray-400 ml-1">Date of Birth</label>
                  <input
                    required
                    type="date"
                    className="w-full px-4 py-3 bg-gray-50/50 border border-gray-100 rounded-xl outline-none focus:ring-4 focus:ring-blue-500/10 focus:bg-white transition-all font-medium text-sm"
                    value={dob}
                    onChange={(e) => setDob(e.target.value)}
                  />
                </div>
                <div className="space-y-1 md:col-span-2">
                  <label className="text-[10px] font-black uppercase tracking-widest text-gray-400 ml-1">Enterprise Email</label>
                  <input
                    required
                    type="email"
                    placeholder="name@company.ai"
                    className="w-full px-4 py-3 bg-gray-50/50 border border-gray-100 rounded-xl outline-none focus:ring-4 focus:ring-blue-500/10 focus:bg-white transition-all font-medium text-sm"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                  />
                </div>
              </div>
            ) : (
              <div className="space-y-5">
                <div className="space-y-1">
                  <label className="text-[10px] font-black uppercase tracking-widest text-gray-400 ml-1">Enterprise Email</label>
                  <input
                    required
                    type="email"
                    placeholder="name@company.ai"
                    className="w-full px-5 py-4 bg-gray-50/50 border border-gray-100 rounded-2xl outline-none focus:ring-4 focus:ring-blue-500/10 focus:bg-white transition-all font-medium"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                  />
                </div>
              </div>
            )}

            <div className="space-y-1">
              <label className="text-[10px] font-black uppercase tracking-widest text-gray-400 ml-1">Account Password</label>
              <input
                required
                type="password"
                placeholder="••••••••"
                className="w-full px-5 py-4 bg-gray-50/50 border border-gray-100 rounded-2xl outline-none focus:ring-4 focus:ring-blue-500/10 focus:bg-white transition-all font-medium"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
              />
            </div>

            {!isSignup && (
              <div className="space-y-1">
                <label className="text-[10px] font-black uppercase tracking-widest text-gray-400 ml-1">Enterprise Access Key</label>
                <input
                  required
                  type="text"
                  placeholder="ETH-XXXXXX"
                  className="w-full px-5 py-4 bg-gray-50/50 border border-gray-100 rounded-2xl outline-none focus:ring-4 focus:ring-blue-500/10 focus:bg-white transition-all font-mono font-black text-blue-600 tracking-widest"
                  value={accessKey}
                  onChange={(e) => setAccessKey(e.target.value.toUpperCase())}
                />
              </div>
            )}

            <button
              type="submit"
              disabled={isLoading}
              className={`w-full py-5 rounded-2xl font-black text-white shadow-xl shadow-blue-500/20 transition-all flex items-center justify-center space-x-3 active:scale-[0.98] mt-4 ${
                isLoading ? 'bg-blue-400 cursor-wait' : 'bg-blue-600 hover:bg-blue-700'
              }`}
            >
              {isLoading ? (
                <>
                  <div className="w-5 h-5 border-2 border-white border-t-transparent animate-spin rounded-full"></div>
                  <span>{isSignup ? 'Creating Identity...' : 'Verifying Identity...'}</span>
                </>
              ) : (
                <span>{isSignup ? 'Create Enterprise Profile' : 'Grant Secure Access'}</span>
              )}
            </button>
          </form>

          <div className="mt-8 pt-8 border-t border-gray-100 flex flex-col items-center">
            <p className="text-sm font-medium text-gray-500 mb-4">
              {isSignup ? "Already have an enterprise profile?" : "New to the marketplace?"}
            </p>
            <button 
              onClick={() => {
                setIsSignup(!isSignup);
                setError('');
                setSuccessKey(null);
              }}
              className="text-xs font-black text-blue-600 uppercase tracking-[0.2em] hover:text-blue-800 transition-colors"
            >
              {isSignup ? 'Switch to Identity Login' : 'Register New Enterprise'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Login;
