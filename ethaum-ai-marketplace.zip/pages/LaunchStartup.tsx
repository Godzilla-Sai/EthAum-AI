
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { geminiService } from '../services/geminiService';
import { storageService } from '../services/storageService';
import { Startup, BadgeLevel } from '../types';

const LaunchStartup: React.FC = () => {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    category: 'AI Agents',
    arrRange: '$0 - $100k',
    description: '',
    website: ''
  });

  const categories = ['AI Agents', 'DevOps', 'FinTech', 'SaaS', 'Marketing', 'Cybersecurity', 'Web3'];
  const arrRanges = ['$0 - $100k', '$100k - $500k', '$500k - $1M', '$1M - $5M', '$5M+'];

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      const assets = await geminiService.generateLaunchAssets(
        formData.name,
        formData.category,
        formData.description
      );

      const newStartup: Startup = {
        id: Math.random().toString(36).substr(2, 9),
        ...formData,
        tagline: assets.tagline || 'Revolutionizing AI solutions',
        summary: assets.summary || 'A cutting-edge platform designed to transform industries.',
        upvotes: 0,
        score: 0,
        badge: BadgeLevel.BRONZE,
        reviews: [],
        createdAt: new Date().toISOString()
      };

      const { score, badge } = await geminiService.calculateCredibilityScore(newStartup);
      newStartup.score = score;
      newStartup.badge = badge;

      // Persistence to Mock MongoDB
      await storageService.saveStartup(newStartup);
      navigate(`/startup/${newStartup.id}`);
    } catch (error) {
      console.error('Launch failed:', error);
      alert('Failed to launch. Please check your API key and try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-3xl mx-auto px-4 py-16">
      <div className="bg-white rounded-2xl shadow-xl border border-gray-100 overflow-hidden">
        <div className="bg-blue-600 px-8 py-6 text-white text-center">
          <h2 className="text-3xl font-black">Launch Your Venture</h2>
          <p className="opacity-80 font-medium">Your data will be safely stored in our verified database.</p>
        </div>
        
        <form onSubmit={handleSubmit} className="p-8 space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <label className="text-xs font-black uppercase tracking-widest text-gray-400">Startup Name</label>
              <input
                required
                type="text"
                placeholder="Acme AI"
                className="w-full px-4 py-3 bg-gray-50 border border-gray-100 rounded-xl outline-none focus:ring-2 focus:ring-blue-500/20 text-black font-medium"
                value={formData.name}
                onChange={e => setFormData({...formData, name: e.target.value})}
              />
            </div>
            <div className="space-y-2">
              <label className="text-xs font-black uppercase tracking-widest text-gray-400">Category</label>
              <select
                className="w-full px-4 py-3 bg-gray-50 border border-gray-100 rounded-xl outline-none focus:ring-2 focus:ring-blue-500/20 text-black font-bold"
                value={formData.category}
                onChange={e => setFormData({...formData, category: e.target.value})}
              >
                {categories.map(c => <option key={c} value={c}>{c}</option>)}
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <label className="text-xs font-black uppercase tracking-widest text-gray-400">ARR Range</label>
              <select
                className="w-full px-4 py-3 bg-gray-50 border border-gray-100 rounded-xl outline-none focus:ring-2 focus:ring-blue-500/20 text-black font-bold"
                value={formData.arrRange}
                onChange={e => setFormData({...formData, arrRange: e.target.value})}
              >
                {arrRanges.map(r => <option key={r} value={r}>{r}</option>)}
              </select>
            </div>
            <div className="space-y-2">
              <label className="text-xs font-black uppercase tracking-widest text-gray-400">Website URL</label>
              <input
                required
                type="url"
                placeholder="https://yourai.com"
                className="w-full px-4 py-3 bg-gray-50 border border-gray-100 rounded-xl outline-none focus:ring-2 focus:ring-blue-500/20 text-black font-medium"
                value={formData.website}
                onChange={e => setFormData({...formData, website: e.target.value})}
              />
            </div>
          </div>

          <div className="space-y-2">
            <label className="text-xs font-black uppercase tracking-widest text-gray-400">Product Scope</label>
            <textarea
              required
              rows={4}
              placeholder="What core problem are you solving? Explain your AI model..."
              className="w-full px-4 py-3 bg-gray-50 border border-gray-100 rounded-xl outline-none focus:ring-2 focus:ring-blue-500/20 text-black font-medium leading-relaxed"
              value={formData.description}
              onChange={e => setFormData({...formData, description: e.target.value})}
            />
          </div>

          <button
            disabled={loading}
            type="submit"
            className={`w-full py-4 rounded-xl font-black text-white transition-all shadow-xl flex items-center justify-center space-x-2 ${
              loading ? 'bg-blue-400 cursor-not-allowed' : 'bg-blue-600 hover:bg-blue-700 shadow-blue-500/20'
            }`}
          >
            {loading ? (
              <>
                <div className="w-5 h-5 border-2 border-white border-t-transparent animate-spin rounded-full"></div>
                <span>DB Write in Progress...</span>
              </>
            ) : (
              'Initialize Startup Document'
            )}
          </button>
        </form>
      </div>
    </div>
  );
};

export default LaunchStartup;
