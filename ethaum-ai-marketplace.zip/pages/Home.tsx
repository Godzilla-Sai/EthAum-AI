
import React, { useEffect, useState, useRef, useCallback } from 'react';
import { Link } from 'react-router-dom';
import { storageService } from '../services/storageService';
import { Startup, FilterCriteria, BadgeLevel } from '../types';
import Badge from '../components/Badge';

const Home: React.FC = () => {
  const [startups, setStartups] = useState<Startup[]>([]);
  const [loading, setLoading] = useState(true);
  const [visibleCount, setVisibleCount] = useState(10);
  const [sortBy, setSortBy] = useState<'trending' | 'newest'>('trending');
  const [topLaunchId, setTopLaunchId] = useState<string | null>(null);
  const [filters, setFilters] = useState<FilterCriteria>({
    searchQuery: '',
    categories: [],
    arrRanges: [],
    badges: []
  });

  const observer = useRef<IntersectionObserver | null>(null);
  
  const lastElementRef = useCallback((node: HTMLAnchorElement | null) => {
    if (observer.current) observer.current.disconnect();
    observer.current = new IntersectionObserver(entries => {
      if (entries[0].isIntersecting) {
        setVisibleCount(prev => prev + 10);
      }
    });
    if (node) observer.current.observe(node);
  }, []);

  const availableCategories = ['AI Agents', 'DevOps', 'FinTech', 'SaaS', 'Marketing', 'Cybersecurity', 'Web3'];
  const availableARR = ['$0 - $100k', '$100k - $500k', '$500k - $1M', '$1M - $5M', '$5M+'];
  const availableBadges = [BadgeLevel.BRONZE, BadgeLevel.SILVER, BadgeLevel.GOLD];

  useEffect(() => {
    const init = async () => {
      await applyFilters();
      const topId = await storageService.getTopLaunchId();
      setTopLaunchId(topId);
    };
    init();
  }, []);

  useEffect(() => {
    applyFilters();
    setVisibleCount(10);
  }, [filters, sortBy]);

  const applyFilters = async () => {
    setLoading(true);
    const filtered = await storageService.queryStartups(filters, sortBy);
    setStartups(filtered);
    setLoading(false);
  };

  const handleUpvote = async (id: string, e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    await storageService.upvoteStartup(id);
    await applyFilters();
    const topId = await storageService.getTopLaunchId();
    setTopLaunchId(topId);
  };

  const toggleFilter = (type: 'categories' | 'arrRanges' | 'badges', value: string) => {
    setFilters(prev => {
      const currentList = prev[type] as string[];
      const newList = currentList.includes(value)
        ? currentList.filter(item => item !== value)
        : [...currentList, value];
      return { ...prev, [type]: newList };
    });
  };

  const clearFilters = () => {
    setFilters({
      searchQuery: '',
      categories: [],
      arrRanges: [],
      badges: []
    });
  };

  const isFilterActive = (type: 'categories' | 'arrRanges' | 'badges', value: string) => {
    return (filters[type] as string[]).includes(value);
  };

  const hasActiveFilters = filters.searchQuery !== '' || filters.categories.length > 0 || filters.arrRanges.length > 0 || filters.badges.length > 0;

  const visibleStartups = startups.slice(0, visibleCount);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
      <header className="mb-14 text-center">
        <h1 className="text-5xl md:text-7xl font-[900] tracking-tight mb-6 text-gray-900 leading-none">
          Invest in <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-600 via-indigo-600 to-purple-600">Pure Innovation</span>
        </h1>
        <p className="text-xl text-gray-500 max-w-2xl mx-auto font-medium leading-relaxed">
          The curated ecosystem for verified AI startups. Backed by proprietary scoring, customer ROI data, and enterprise validation.
        </p>
      </header>

      <div className="glass-card rounded-[2.5rem] p-8 shadow-2xl shadow-blue-900/5 mb-14 transition-all border border-white/40">
        <div className="relative mb-8 group">
          <div className="absolute inset-y-0 left-0 pl-5 flex items-center pointer-events-none">
            <svg className="h-6 w-6 text-blue-500/50 group-focus-within:text-blue-500 transition-colors" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
            </svg>
          </div>
          <input
            type="text"
            className="block w-full pl-14 pr-6 py-5 bg-white/40 border border-white/20 rounded-2xl focus:ring-4 focus:ring-blue-500/10 focus:border-blue-500/50 outline-none transition-all text-xl font-medium placeholder:text-gray-400"
            placeholder="Search the future of AI..."
            value={filters.searchQuery}
            onChange={(e) => setFilters({ ...filters, searchQuery: e.target.value })}
          />
        </div>

        <div className="space-y-6">
          <div>
            <p className="text-[10px] font-black uppercase tracking-[0.2em] text-gray-400 mb-3">Categories</p>
            <div className="flex flex-wrap gap-2">
              <button
                onClick={() => setFilters(prev => ({ ...prev, categories: [] }))}
                className={`px-4 py-2 rounded-xl text-sm font-bold transition-all border ${
                  filters.categories.length === 0 ? 'bg-blue-600 text-white border-blue-600 shadow-lg shadow-blue-500/20' : 'bg-white/50 text-gray-500 border-white/10 hover:bg-white'
                }`}
              >
                All Categories
              </button>
              {availableCategories.map(cat => (
                <button
                  key={cat}
                  onClick={() => toggleFilter('categories', cat)}
                  className={`px-4 py-2 rounded-xl text-sm font-bold transition-all border ${
                    isFilterActive('categories', cat) ? 'bg-blue-600 text-white border-blue-600 shadow-lg shadow-blue-500/20' : 'bg-white/50 text-gray-500 border-white/10 hover:bg-white'
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div>
              <p className="text-[10px] font-black uppercase tracking-[0.2em] text-gray-400 mb-3">ARR Range</p>
              <div className="flex flex-wrap gap-2">
                <button
                  onClick={() => setFilters(prev => ({ ...prev, arrRanges: [] }))}
                  className={`px-4 py-2 rounded-xl text-sm font-bold transition-all border ${
                    filters.arrRanges.length === 0 ? 'bg-indigo-600 text-white border-indigo-600 shadow-lg shadow-indigo-500/20' : 'bg-white/50 text-gray-500 border-white/10 hover:bg-white'
                  }`}
                >
                  Any ARR
                </button>
                {availableARR.map(range => (
                  <button
                    key={range}
                    onClick={() => toggleFilter('arrRanges', range)}
                    className={`px-4 py-2 rounded-xl text-sm font-bold transition-all border ${
                      isFilterActive('arrRanges', range) ? 'bg-indigo-600 text-white border-indigo-600 shadow-lg shadow-indigo-500/20' : 'bg-white/50 text-gray-500 border-white/10 hover:bg-white'
                    }`}
                  >
                    {range}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <p className="text-[10px] font-black uppercase tracking-[0.2em] text-gray-400 mb-3">Verified Status</p>
              <div className="flex flex-wrap gap-2">
                <button
                  onClick={() => setFilters(prev => ({ ...prev, badges: [] }))}
                  className={`px-4 py-2 rounded-xl text-sm font-bold transition-all border ${
                    filters.badges.length === 0 ? 'bg-purple-600 text-white border-purple-600 shadow-lg shadow-purple-500/20' : 'bg-white/50 text-gray-500 border-white/10 hover:bg-white'
                  }`}
                >
                  Any Status
                </button>
                {availableBadges.map(badge => (
                  <button
                    key={badge}
                    onClick={() => toggleFilter('badges', badge)}
                    className={`px-4 py-2 rounded-xl text-sm font-bold transition-all border ${
                      isFilterActive('badges', badge) ? 'bg-purple-600 text-white border-purple-600 shadow-lg shadow-purple-500/20' : 'bg-white/50 text-gray-500 border-white/10 hover:bg-white'
                    }`}
                  >
                    {badge}
                  </button>
                ))}
              </div>
            </div>
          </div>

          <div className="pt-4 border-t border-white/20 flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div className="flex items-center space-x-2 bg-gray-100/50 p-1.5 rounded-xl border border-gray-200/50 w-fit">
              <button
                onClick={() => setSortBy('trending')}
                className={`px-5 py-2 rounded-lg text-xs font-black uppercase tracking-widest transition-all ${
                  sortBy === 'trending' ? 'bg-white text-blue-600 shadow-sm' : 'text-gray-400 hover:text-gray-600'
                }`}
              >
                Trending
              </button>
              <button
                onClick={() => setSortBy('newest')}
                className={`px-5 py-2 rounded-lg text-xs font-black uppercase tracking-widest transition-all ${
                  sortBy === 'newest' ? 'bg-white text-blue-600 shadow-sm' : 'text-gray-400 hover:text-gray-600'
                }`}
              >
                Newest
              </button>
            </div>
            
            {hasActiveFilters && (
              <button
                onClick={clearFilters}
                className="text-xs font-black text-blue-600 hover:text-blue-800 transition-colors uppercase tracking-widest px-4 py-2 bg-blue-50 rounded-lg w-fit self-end"
              >
                Clear All Filters
              </button>
            )}
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 gap-8 min-h-[400px]">
        {loading ? (
          <div className="flex flex-col space-y-8">
            {[...Array(3)].map((_, i) => (
              <div key={i} className="animate-pulse bg-white/20 h-64 rounded-[2rem]"></div>
            ))}
          </div>
        ) : startups.length === 0 ? (
          <div className="bg-white/40 backdrop-blur-md border-2 border-dashed border-gray-200/50 rounded-[2.5rem] p-24 text-center">
            <div className="text-6xl mb-6">🪐</div>
            <h3 className="text-2xl font-black text-gray-900 mb-2">Beyond the horizon</h3>
            <p className="text-gray-500 font-medium mb-8">No startups match these precise parameters. Expand your search or try different categories.</p>
            <button onClick={clearFilters} className="bg-blue-600 text-white px-8 py-3 rounded-xl font-bold hover:bg-blue-700 shadow-xl shadow-blue-500/20 transition-all active:scale-95">Reset Marketplace</button>
          </div>
        ) : (
          visibleStartups.map((startup, index) => {
            const isTopLaunch = startup.id === topLaunchId;
            return (
              <Link 
                key={startup.id} 
                to={`/startup/${startup.id}`}
                ref={index === visibleStartups.length - 1 ? lastElementRef : null}
                className={`group glass-card rounded-[2rem] p-8 transition-all flex flex-col md:flex-row items-start md:items-center space-y-6 md:space-y-0 md:space-x-10 relative overflow-hidden ${
                  isTopLaunch 
                    ? 'border-amber-300 bg-gradient-to-br from-white to-amber-50/30 shadow-2xl shadow-amber-500/10 scale-[1.01]' 
                    : 'hover:shadow-2xl hover:shadow-blue-900/10'
                }`}
              >
                {isTopLaunch && (
                  <div className="absolute top-0 left-0 bg-gradient-to-r from-amber-400 via-orange-500 to-amber-600 text-white px-6 py-1.5 text-[10px] font-black uppercase tracking-[0.25em] rounded-br-2xl shadow-xl z-20 flex items-center space-x-1.5 animate-pulse">
                    <span>🔥</span>
                    <span>Top Launch This Week</span>
                  </div>
                )}

                <div className={`absolute top-0 right-0 w-32 h-32 rounded-full blur-2xl translate-x-16 -translate-y-16 transition-all ${
                  isTopLaunch ? 'bg-amber-500/10' : 'bg-blue-500/5 group-hover:bg-blue-500/10'
                }`}></div>
                
                <div className={`flex-shrink-0 w-24 h-24 rounded-[2rem] flex items-center justify-center text-4xl font-black shadow-xl transition-transform group-hover:scale-105 ${
                  isTopLaunch 
                    ? 'bg-gradient-to-br from-amber-500 to-orange-600 text-white shadow-amber-500/20' 
                    : 'bg-gradient-to-br from-blue-600 to-indigo-700 text-white shadow-blue-500/20'
                }`}>
                  {startup.name[0].toUpperCase()}
                </div>
                
                <div className="flex-grow relative z-10">
                  <div className="flex flex-wrap items-center gap-4 mb-3">
                    <h3 className={`text-3xl font-black transition-colors leading-tight ${
                      isTopLaunch ? 'text-amber-900' : 'text-gray-900 group-hover:text-blue-600'
                    }`}>
                      {startup.name}
                    </h3>
                    <Badge level={startup.badge} score={startup.score} />
                  </div>
                  <p className={`font-bold text-lg mb-3 ${isTopLaunch ? 'text-amber-700' : 'text-blue-600'}`}>
                    {startup.tagline}
                  </p>
                  <p className="text-gray-500 font-medium leading-relaxed line-clamp-2 max-w-3xl">
                    {startup.summary}
                  </p>
                  <div className="mt-6 flex flex-wrap items-center gap-4">
                    <span className={`px-3 py-1 rounded-lg text-xs font-black uppercase tracking-widest ${
                      isTopLaunch ? 'bg-amber-100 text-amber-700' : 'bg-blue-100/50 text-blue-700'
                    }`}>
                      {startup.category}
                    </span>
                    <div className="h-1 w-1 bg-gray-300 rounded-full"></div>
                    <span className="text-xs font-bold text-gray-400 uppercase tracking-tighter">ARR: {startup.arrRange}</span>
                    <div className="h-1 w-1 bg-gray-300 rounded-full"></div>
                    <span className="text-xs font-bold text-gray-400 uppercase tracking-tighter">{startup.reviews.length} Verified Reviews</span>
                  </div>
                </div>

                <button 
                  onClick={(e) => handleUpvote(startup.id, e)}
                  className={`flex flex-col items-center justify-center border rounded-2xl px-6 py-4 shadow-sm transition-all min-w-[110px] z-20 hover:scale-105 active:scale-95 ${
                    isTopLaunch 
                      ? 'bg-amber-50 border-amber-200 group-hover:bg-amber-100 group-hover:border-amber-300' 
                      : 'bg-white border-gray-200 group-hover:border-blue-300 group-hover:bg-blue-50'
                  }`}
                >
                  <svg className={`w-6 h-6 mb-1 transition-colors ${
                    isTopLaunch ? 'text-amber-400 group-hover:text-amber-600' : 'text-gray-300 group-hover:text-blue-500'
                  }`} fill="currentColor" viewBox="0 0 20 20">
                    <path fillRule="evenodd" d="M14.707 12.707a1 1 0 01-1.414 0L10 9.414l-3.293 3.293a1 1 0 01-1.414-1.414l4-4a1 1 0 011.414 0l4 4a1 1 0 010 1.414z" clipRule="evenodd" />
                  </svg>
                  <span className={`text-2xl font-black leading-none ${isTopLaunch ? 'text-amber-900' : 'text-gray-900'}`}>
                    {startup.upvotes}
                  </span>
                  <span className={`text-[9px] font-black uppercase mt-1 tracking-widest ${
                    isTopLaunch ? 'text-amber-400' : 'text-gray-400 group-hover:text-blue-400'
                  }`}>Upvotes</span>
                </button>
              </Link>
            );
          })
        )}
      </div>
    </div>
  );
};

export default Home;
