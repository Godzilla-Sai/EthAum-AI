
import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import { storageService } from '../services/storageService';
import { geminiService } from '../services/geminiService';
import { Startup, Review, ValidationReport } from '../types';
import Badge from '../components/Badge';
import { jsPDF } from 'jspdf';

const StartupDetails: React.FC = () => {
  const { id } = useParams();
  const [startup, setStartup] = useState<Startup | null>(null);
  const [loading, setLoading] = useState(true);
  const [reviewLoading, setReviewLoading] = useState(false);
  const [validationLoading, setValidationLoading] = useState(false);
  const [newReview, setNewReview] = useState({ text: '', rating: 5, user: '' });
  const [showEmbedCode, setShowEmbedCode] = useState(false);

  useEffect(() => {
    const fetchStartup = async () => {
      if (id) {
        setLoading(true);
        const data = await storageService.getStartupById(id);
        if (data) setStartup(data);
        setLoading(false);
      }
    };
    fetchStartup();
  }, [id]);

  const handleReviewSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!startup || !id) return;

    setReviewLoading(true);
    try {
      const analysis = await geminiService.analyzeReview(newReview.text);
      
      const review: Review = {
        id: Math.random().toString(36).substr(2, 9),
        startupId: id,
        user: newReview.user || 'Anonymous User',
        text: newReview.text,
        rating: newReview.rating,
        analysis,
        createdAt: new Date().toISOString()
      };

      await storageService.addReview(id, review);
      
      const updatedStartup = await storageService.getStartupById(id);
      if (updatedStartup) {
        const { score, badge } = await geminiService.calculateCredibilityScore(updatedStartup);
        updatedStartup.score = score;
        updatedStartup.badge = badge;
        await storageService.updateStartup(updatedStartup);
        setStartup(updatedStartup);
      }
      
      setNewReview({ text: '', rating: 5, user: '' });
    } finally {
      setReviewLoading(false);
    }
  };

  const handleUpvote = async () => {
    if (!id || !startup) return;
    await storageService.upvoteStartup(id);
    const updated = await storageService.getStartupById(id);
    if (updated) setStartup(updated);
  };

  const generateValidation = async () => {
    if (!startup || !id) return;
    setValidationLoading(true);
    try {
      const report = await geminiService.generateValidationReport(startup);
      const updatedStartup = { ...startup, validationReport: report };
      await storageService.updateStartup(updatedStartup);
      setStartup(updatedStartup);
    } catch (err) {
      console.error('Validation failed', err);
      alert('Failed to generate report. Please check your API connection.');
    } finally {
      setValidationLoading(false);
    }
  };

  const handleExportPDF = () => {
    if (!startup || !startup.validationReport) return;

    const doc = new jsPDF();
    const report = startup.validationReport;
    const margin = 20;
    let y = margin;

    // Header
    doc.setFontSize(22);
    doc.setTextColor(30, 41, 59); // slate-800
    doc.text('EthAum AI Validation Report', margin, y);
    y += 15;

    doc.setFontSize(16);
    doc.text(`${startup.name}`, margin, y);
    y += 10;

    doc.setFontSize(12);
    doc.setTextColor(100, 116, 139); // slate-500
    doc.text(`Generated on: ${new Date().toLocaleDateString()}`, margin, y);
    y += 20;

    // Strengths
    doc.setFontSize(14);
    doc.setTextColor(16, 185, 129); // emerald-500
    doc.text('Market Strengths', margin, y);
    y += 8;
    doc.setFontSize(11);
    doc.setTextColor(71, 85, 105); // slate-600
    report.strengths.forEach((strength) => {
      const lines = doc.splitTextToSize(`• ${strength}`, 170);
      doc.text(lines, margin, y);
      y += (lines.length * 6);
    });
    y += 10;

    // Risks
    doc.setFontSize(14);
    doc.setTextColor(225, 29, 72); // rose-600
    doc.text('Risk Vectors', margin, y);
    y += 8;
    doc.setFontSize(11);
    doc.setTextColor(71, 85, 105);
    report.risks.forEach((risk) => {
      const lines = doc.splitTextToSize(`• ${risk}`, 170);
      doc.text(lines, margin, y);
      y += (lines.length * 6);
    });
    y += 15;

    // Market Readiness
    doc.setFontSize(14);
    doc.setTextColor(79, 70, 229); // indigo-600
    doc.text('Market Readiness Analysis', margin, y);
    y += 8;
    doc.setFontSize(11);
    doc.setTextColor(71, 85, 105);
    const readinessLines = doc.splitTextToSize(report.marketReadiness, 170);
    doc.text(readinessLines, margin, y);
    y += (readinessLines.length * 6) + 15;

    // Strategic Recommendation
    doc.setFontSize(14);
    doc.setTextColor(30, 41, 59);
    doc.text('Strategic Recommendation', margin, y);
    y += 8;
    doc.setFontSize(11);
    doc.setFont("helvetica", "italic");
    const recommendationLines = doc.splitTextToSize(report.recommendation, 170);
    doc.text(recommendationLines, margin, y);
    
    // Footer
    doc.setFontSize(10);
    doc.setFont("helvetica", "normal");
    doc.setTextColor(148, 163, 184); // slate-400
    doc.text('EthAum AI Marketplace Verified Document', margin, 280);

    doc.save(`${startup.name}_Validation_Report.pdf`);
  };

  if (loading) return <div className="p-20 text-center animate-pulse text-gray-400">Fetching document from database...</div>;
  if (!startup) return <div className="p-20 text-center">Startup not found.</div>;

  return (
    <div className="max-w-6xl mx-auto px-4 py-12">
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
        <div className="lg:col-span-2 space-y-8">
          <div className="bg-white p-8 rounded-3xl border border-gray-200 shadow-sm relative overflow-hidden transition-all hover:shadow-md">
            <div className="absolute top-0 right-0 p-6 flex flex-col items-end space-y-2">
              <button 
                onClick={() => setShowEmbedCode(!showEmbedCode)}
                className="text-[10px] font-black text-blue-600 uppercase tracking-widest hover:text-blue-800 transition-colors"
              >
                Get Badge Widget
              </button>
            </div>
            
            <div className="flex flex-col md:flex-row md:items-center justify-between mb-8 gap-6">
              <div className="flex items-center space-x-6">
                 <div className="w-24 h-24 bg-gradient-to-br from-blue-600 to-indigo-700 text-white rounded-3xl flex items-center justify-center text-4xl font-black shadow-xl shadow-blue-500/20">
                  {startup.name[0].toUpperCase()}
                </div>
                <div>
                  <h1 className="text-4xl font-black text-gray-900 tracking-tight">{startup.name}</h1>
                  <p className="text-blue-600 font-bold text-lg">{startup.tagline}</p>
                  <a href={startup.website} target="_blank" rel="noopener noreferrer" className="text-xs text-gray-400 font-medium hover:text-blue-500 transition-colors flex items-center mt-1">
                    {startup.website.replace(/^https?:\/\//, '')}
                    <svg className="w-3 h-3 ml-1" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/></svg>
                  </a>
                </div>
              </div>

              <button 
                onClick={handleUpvote}
                className="flex items-center space-x-3 bg-blue-50 border border-blue-100 rounded-2xl px-6 py-3 transition-all hover:bg-blue-100 hover:border-blue-200 active:scale-95 group shadow-sm w-fit"
              >
                <div className="flex flex-col items-center">
                  <svg className="w-5 h-5 text-blue-600 transition-transform group-hover:-translate-y-1" fill="currentColor" viewBox="0 0 20 20">
                    <path fillRule="evenodd" d="M14.707 12.707a1 1 0 01-1.414 0L10 9.414l-3.293 3.293a1 1 0 01-1.414-1.414l4-4a1 1 0 011.414 0l4 4a1 1 0 010 1.414z" clipRule="evenodd" />
                  </svg>
                  <span className="text-xl font-black text-blue-900 leading-none">{startup.upvotes}</span>
                </div>
                <div className="text-left">
                  <span className="block text-[10px] font-black uppercase tracking-widest text-blue-400">Upvotes</span>
                  <span className="block text-xs font-bold text-blue-700">Support Venture</span>
                </div>
              </button>
            </div>

            <div className="mb-8 flex flex-wrap gap-4 items-center border-b border-gray-50 pb-8">
              <Badge level={startup.badge} score={startup.score} />
              <button
                disabled={validationLoading}
                onClick={generateValidation}
                className={`px-5 py-2.5 rounded-xl text-xs font-black uppercase tracking-widest transition-all shadow-sm flex items-center space-x-2 ${
                  validationLoading 
                    ? 'bg-gray-100 text-gray-400 cursor-not-allowed' 
                    : 'bg-white text-blue-600 border border-blue-100 hover:bg-blue-50 hover:shadow-blue-500/10'
                }`}
              >
                {validationLoading ? (
                  <>
                    <div className="w-3 h-3 border-2 border-blue-600 border-t-transparent animate-spin rounded-full"></div>
                    <span>Analyzing...</span>
                  </>
                ) : (
                  <>
                    <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M9.663 17h4.674a1 1 0 00.908-.588l3.358-7.659a1 1 0 00-.908-1.353H14.11L11.5 3h-.172a1 1 0 00-.908.588L7.062 11.247a1 1 0 00.908 1.353h3.541l-1.848 4.4z"/></svg>
                    <span>{startup.validationReport ? 'Regenerate Validation Report' : 'Generate AI Validation Report'}</span>
                  </>
                )}
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
              <div className="space-y-4">
                <h3 className="text-xs font-black text-gray-400 uppercase tracking-[0.2em]">Executive Summary</h3>
                <p className="text-gray-600 leading-relaxed font-medium">{startup.summary}</p>
              </div>
              <div className="space-y-4">
                <h3 className="text-xs font-black text-gray-400 uppercase tracking-[0.2em]">Technical Scope</h3>
                <p className="text-gray-600 leading-relaxed font-medium line-clamp-4">{startup.description}</p>
              </div>
            </div>

            {startup.validationReport && (
              <div className="mt-12 p-8 bg-gradient-to-br from-indigo-50/80 to-blue-50/50 rounded-[2rem] border border-indigo-100/50 shadow-inner relative group/report">
                <div className="flex items-center justify-between mb-8">
                  <div className="flex items-center space-x-3">
                    <div className="bg-indigo-600 p-2 rounded-xl text-white shadow-lg shadow-indigo-200">
                      <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M13 10V3L4 14h7v7l9-11h-7z"/></svg>
                    </div>
                    <h3 className="text-2xl font-black text-indigo-950 tracking-tight">AI Insights Report</h3>
                  </div>
                  <button 
                    onClick={handleExportPDF}
                    className="bg-white/80 hover:bg-white text-indigo-600 px-4 py-2 rounded-xl text-xs font-black uppercase tracking-widest border border-indigo-100 shadow-sm transition-all flex items-center space-x-2 group active:scale-95"
                  >
                    <svg className="w-4 h-4 group-hover:translate-y-0.5 transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/></svg>
                    <span>Export Report (PDF)</span>
                  </button>
                </div>
                
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
                  <div className="space-y-6">
                    <div>
                      <h4 className="text-[10px] font-black text-emerald-600 uppercase tracking-[0.25em] mb-4 flex items-center">
                        <span className="w-4 h-4 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mr-2 text-[8px]">★</span>
                        Market Strengths
                      </h4>
                      <div className="space-y-3">
                        {startup.validationReport.strengths.map((s, i) => (
                          <div key={i} className="flex items-start bg-white/60 p-3 rounded-xl border border-white shadow-sm">
                            <span className="text-emerald-500 mr-3 font-bold">+</span>
                            <p className="text-sm font-bold text-gray-700 leading-tight">{s}</p>
                          </div>
                        ))}
                      </div>
                    </div>

                    <div>
                      <h4 className="text-[10px] font-black text-rose-600 uppercase tracking-[0.25em] mb-4 flex items-center">
                        <span className="w-4 h-4 bg-rose-100 text-rose-600 rounded-full flex items-center justify-center mr-2 text-[8px]">!</span>
                        Risk Vectors
                      </h4>
                      <div className="space-y-3">
                        {startup.validationReport.risks.map((r, i) => (
                          <div key={i} className="flex items-start bg-white/60 p-3 rounded-xl border border-white shadow-sm">
                            <span className="text-rose-400 mr-3 font-bold">•</span>
                            <p className="text-sm font-bold text-gray-700 leading-tight">{r}</p>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>

                  <div className="flex flex-col justify-between space-y-8">
                    <div className="bg-white/80 backdrop-blur-sm p-6 rounded-[1.5rem] border border-white shadow-xl shadow-indigo-900/5">
                      <h4 className="text-[10px] font-black text-indigo-500 uppercase tracking-[0.25em] mb-4">Market Readiness Analysis</h4>
                      <p className="text-sm font-bold text-gray-800 leading-relaxed mb-6">{startup.validationReport.marketReadiness}</p>
                      
                      <div className="space-y-2">
                         <div className="flex justify-between items-center mb-1">
                            <span className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Execution Potential</span>
                            <span className="text-xs font-black text-indigo-600">Verified</span>
                         </div>
                         <div className="h-2 bg-indigo-100 rounded-full overflow-hidden">
                            <div className="h-full bg-indigo-600 rounded-full" style={{ width: `${startup.score}%` }}></div>
                         </div>
                      </div>
                    </div>

                    <div className="bg-indigo-950 p-6 rounded-[1.5rem] text-white shadow-2xl shadow-indigo-950/20 relative overflow-hidden">
                      <div className="absolute top-0 right-0 w-24 h-24 bg-white/5 rounded-full blur-2xl -translate-y-8 translate-x-8"></div>
                      <h4 className="text-[10px] font-black text-indigo-300 uppercase tracking-[0.25em] mb-3">Strategic Recommendation</h4>
                      <p className="text-base font-medium leading-relaxed italic opacity-90">"{startup.validationReport.recommendation}"</p>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>

          <div className="space-y-8">
            <h2 className="text-2xl font-black text-gray-900 tracking-tight flex items-center">
              Customer ROI Testimonials
              <span className="ml-3 px-2 py-0.5 bg-gray-100 text-gray-400 text-[10px] rounded-full">{startup.reviews.length}</span>
            </h2>
            <div className="grid grid-cols-1 gap-6">
              {startup.reviews.length === 0 ? (
                <div className="bg-white/40 border-2 border-dashed border-gray-200 rounded-3xl p-12 text-center">
                  <p className="text-gray-400 font-medium italic">No testimonials recorded yet. Be the first to validate this venture.</p>
                </div>
              ) : (
                startup.reviews.map(review => (
                  <div key={review.id} className="bg-white p-8 rounded-3xl border border-gray-100 shadow-sm transition-all hover:shadow-md">
                    <div className="flex justify-between items-start mb-6">
                      <div className="flex items-center space-x-3">
                         <div className="w-10 h-10 bg-blue-50 text-blue-600 rounded-xl flex items-center justify-center font-black text-sm">
                            {review.user[0].toUpperCase()}
                         </div>
                         <div>
                           <span className="font-black text-gray-900 block leading-none mb-1">{review.user}</span>
                           <div className="flex space-x-0.5">
                              {[...Array(5)].map((_, i) => (
                                <span key={i} className={`text-sm ${i < review.rating ? 'text-yellow-400' : 'text-gray-200'}`}>★</span>
                              ))}
                           </div>
                         </div>
                      </div>
                      <span className="text-[10px] font-black text-gray-300 uppercase tracking-widest">{new Date(review.createdAt).toLocaleDateString()}</span>
                    </div>
                    <p className="text-gray-600 mb-8 leading-relaxed font-medium">"{review.text}"</p>
                    {review.analysis && (
                      <div className="bg-blue-50/50 p-6 rounded-2xl border border-blue-100/50 grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div>
                          <p className="text-[9px] uppercase font-black text-blue-400 mb-2 tracking-[0.2em]">Validated ROI</p>
                          <p className="text-sm font-bold text-blue-900 leading-tight">{review.analysis.roi}</p>
                        </div>
                        <div>
                          <p className="text-[9px] uppercase font-black text-blue-400 mb-2 tracking-[0.2em]">Core Implementation</p>
                          <p className="text-sm font-bold text-blue-900 leading-tight">{review.analysis.useCase}</p>
                        </div>
                      </div>
                    )}
                  </div>
                ))
              )}
            </div>
          </div>
        </div>

        <div className="space-y-8">
          <div className="bg-white p-8 rounded-[2.5rem] border border-gray-200 shadow-xl shadow-blue-900/5 sticky top-24">
            <h3 className="text-2xl font-black text-gray-900 mb-8 tracking-tight">Submit Validation</h3>
            <form onSubmit={handleReviewSubmit} className="space-y-6">
              <div className="space-y-2">
                <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Full Name</label>
                <input
                  required
                  type="text"
                  placeholder="John Doe"
                  className="w-full px-4 py-3 bg-gray-50 border border-gray-100 rounded-xl outline-none focus:ring-2 focus:ring-blue-500/20 focus:bg-white transition-all font-medium text-black"
                  value={newReview.user}
                  onChange={e => setNewReview({...newReview, user: e.target.value})}
                />
              </div>
              <div className="space-y-2">
                <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Experience Rating</label>
                <select
                  className="w-full px-4 py-3 bg-gray-50 border border-gray-100 rounded-xl outline-none focus:ring-2 focus:ring-blue-500/20 focus:bg-white transition-all font-bold text-black appearance-none cursor-pointer"
                  value={newReview.rating}
                  onChange={e => setNewReview({...newReview, rating: Number(e.target.value)})}
                >
                  <option value={5}>5 Stars - Excellence</option>
                  <option value={4}>4 Stars - High Quality</option>
                  <option value={3}>3 Stars - Satisfactory</option>
                  <option value={2}>2 Stars - Needs Improvement</option>
                  <option value={1}>1 Star - Critical Issues</option>
                </select>
              </div>
              <div className="space-y-2">
                <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Testimonial Context</label>
                <textarea
                  required
                  rows={4}
                  placeholder="Describe your implementation and the business impact..."
                  className="w-full px-4 py-3 bg-gray-50 border border-gray-100 rounded-xl outline-none focus:ring-2 focus:ring-blue-500/20 focus:bg-white transition-all font-medium leading-relaxed text-black"
                  value={newReview.text}
                  onChange={e => setNewReview({...newReview, text: e.target.value})}
                />
              </div>
              <button
                disabled={reviewLoading}
                type="submit"
                className={`w-full py-4 rounded-xl font-black text-white transition-all shadow-lg shadow-blue-500/20 active:scale-[0.98] flex items-center justify-center space-x-2 ${
                  reviewLoading ? 'bg-blue-400 cursor-wait' : 'bg-blue-600 hover:bg-blue-700'
                }`}
              >
                {reviewLoading ? (
                  <>
                    <div className="w-4 h-4 border-2 border-white border-t-transparent animate-spin rounded-full"></div>
                    <span>Extracting Signals...</span>
                  </>
                ) : (
                  <span>Submit for AI Validation</span>
                )}
              </button>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
};

export default StartupDetails;
