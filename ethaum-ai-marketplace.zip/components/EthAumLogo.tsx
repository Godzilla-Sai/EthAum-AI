
import React from 'react';

const EthAumLogo: React.FC<{ className?: string }> = ({ className }) => {
  return (
    <div className={`flex items-center justify-center ${className}`}>
      <svg 
        viewBox="0 0 400 320" 
        xmlns="http://www.w3.org/2000/svg" 
        className="h-full w-auto"
        preserveAspectRatio="xMidYMid meet"
      >
        <defs>
          <linearGradient id="ethaumLogoGradient" x1="0%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" style={{ stopColor: '#52E5E7', stopOpacity: 1 }} />
            <stop offset="100%" style={{ stopColor: '#BC7AF9', stopOpacity: 1 }} />
          </linearGradient>
        </defs>
        
        <g fill="url(#ethaumLogoGradient)">
          {/* TOP SECTION: Head and Shoulders (Iconography) */}
          <circle cx="200" cy="55" r="32" />
          <path d="M120 85 L200 135 L280 85 L280 110 L200 160 L120 110 Z" />
          <path d="M110 115 L145 138 L145 150 L110 127 Z" /> {/* Left shoulder detail */}
          <path d="M290 115 L255 138 L255 150 L290 127 Z" /> {/* Right shoulder detail */}

          {/* MIDDLE SECTION: Custom Wordmark (ETHAUM) */}
          <g transform="translate(45, 175)">
            {/* E: Square geometric block */}
            <path d="M0 0 H40 V10 H10 V20 H35 V30 H10 V40 H40 V50 H0 Z" />
            {/* T: Sharp horizontal with centered vertical stem */}
            <path d="M50 0 H90 V10 H75 V50 H65 V10 H50 Z" />
            {/* H: Parallel verticals with center bridge */}
            <path d="M100 0 H110 V20 H130 V0 H140 V50 H130 V30 H110 V50 H100 Z" />
            {/* A: Lambda style (stylized as an upside-down V) */}
            <path d="M150 50 L170 0 L190 50 H180 L170 25 L160 50 Z" />
            {/* U: Symmetrical square-base U */}
            <path d="M200 0 H210 V40 H230 V0 H240 V40 Q240 50 230 50 H210 Q200 50 200 40 Z" />
            {/* M: Precisely traced M with downward center peak for 'ETHAUM' clarity */}
            <path d="M250 0 H262 L275 30 L288 0 H300 V50 H288 V15 L275 45 L262 15 V50 H250 Z" />
          </g>

          {/* BOTTOM SECTION: Central Shield and floating circles */}
          <circle cx="120" cy="255" r="30" />
          <circle cx="280" cy="255" r="30" />
          
          {/* Central Shield/Pillar Component */}
          <path d="M180 220 H220 V300 L200 320 L180 300 Z" />
          {/* Decorative side accent lines */}
          <path d="M165 220 H175 V285 L165 275 Z" />
          <path d="M235 220 H225 V285 L235 275 Z" />
        </g>
      </svg>
    </div>
  );
};

export default EthAumLogo;
