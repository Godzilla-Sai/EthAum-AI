
import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import EthAumLogo from './EthAumLogo';
import { authService } from '../services/authService';

const Navbar: React.FC = () => {
  const user = authService.getCurrentUser();
  const navigate = useNavigate();

  const handleLogout = () => {
    authService.logout();
    navigate('/login');
  };

  return (
    <nav className="sticky top-0 z-50 bg-white/60 backdrop-blur-xl border-b border-white/20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-20 items-center">
          <div className="flex items-center space-x-8">
            <Link to="/" className="flex items-center hover:opacity-80 transition-opacity">
              <EthAumLogo className="h-16" />
              <div className="ml-4 flex items-center space-x-2">
                <span className="text-gray-300 font-light text-xl">|</span>
                <span className="text-[10px] font-black text-gray-700 uppercase tracking-[0.2em] opacity-80 mt-1">AI Marketplace</span>
              </div>
            </Link>
            <div className="hidden md:flex space-x-6 ml-4">
              <Link to="/" className="text-gray-600 hover:text-blue-600 font-bold text-sm transition-colors">Marketplace</Link>
              <Link to="/match" className="text-gray-600 hover:text-blue-600 font-bold text-sm transition-colors">Enterprise Match</Link>
            </div>
          </div>
          
          <div className="flex items-center space-x-6">
            <div className="hidden lg:flex flex-col items-end mr-2">
              <span className="text-xs font-black text-gray-900 leading-none">{user?.name}</span>
              <span className="text-[9px] font-black uppercase text-blue-500 tracking-tighter mt-1">{user?.role}</span>
            </div>
            
            <Link 
              to="/launch" 
              className="bg-blue-600 text-white px-6 py-2.5 rounded-xl text-sm font-bold hover:bg-blue-700 transition-all shadow-lg shadow-blue-500/20 active:scale-95"
            >
              Launch Startup
            </Link>
            
            <button 
              onClick={handleLogout}
              className="p-2 text-gray-400 hover:text-rose-600 transition-colors group"
              title="Logout"
            >
              <svg className="w-5 h-5 group-hover:translate-x-0.5 transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1" />
              </svg>
            </button>
          </div>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
