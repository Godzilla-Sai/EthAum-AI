
import React, { useState, useRef, useEffect } from 'react';
import { geminiService, audioUtils } from '../services/geminiService';
import { storageService } from '../services/storageService';

const ChatBot: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<{ role: 'user' | 'bot'; text: string }[]>([]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const chatRef = useRef<any>(null);
  const scrollRef = useRef<HTMLDivElement>(null);
  const [audioLoading, setAudioLoading] = useState<number | null>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const initChat = async () => {
    const startups = await storageService.getAllStartups();
    const context = JSON.stringify(startups.map(s => ({
      name: s.name,
      tagline: s.tagline,
      category: s.category,
      score: s.score,
      badge: s.badge
    })));
    chatRef.current = geminiService.createAssistantChat(context);
  };

  const handleSend = async () => {
    if (!input.trim()) return;
    
    if (!chatRef.current) await initChat();

    const userMessage = input;
    setMessages(prev => [...prev, { role: 'user', text: userMessage }]);
    setInput('');
    setIsLoading(true);

    try {
      const responseStream = await chatRef.current.sendMessageStream({ message: userMessage });
      let botText = '';
      setMessages(prev => [...prev, { role: 'bot', text: '' }]);

      for await (const chunk of responseStream) {
        botText += chunk.text;
        setMessages(prev => {
          const updated = [...prev];
          updated[updated.length - 1].text = botText;
          return updated;
        });
      }
    } catch (err) {
      console.error(err);
      setMessages(prev => [...prev, { role: 'bot', text: 'Sorry, I encountered an error. Please try again.' }]);
    } finally {
      setIsLoading(false);
    }
  };

  const speak = async (text: string, index: number) => {
    if (audioLoading !== null) return;
    setAudioLoading(index);
    try {
      const base64Audio = await geminiService.generateSpeech(text);
      if (base64Audio) {
        const audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
        const audioBuffer = await audioUtils.decodeAudioData(
          audioUtils.decode(base64Audio),
          audioCtx,
          24000,
          1
        );
        const source = audioCtx.createBufferSource();
        source.buffer = audioBuffer;
        source.connect(audioCtx.destination);
        source.start();
      } else {
        throw new Error("No audio data returned from Gemini");
      }
    } catch (err) {
      console.error('Speech error', err);
    } finally {
      setAudioLoading(null);
    }
  };

  /**
   * Refined formatter to ensure "continuous" text flow.
   * Removes bold markers, excessive whitespace, and conversational prefixes.
   */
  const formatBotText = (text: string) => {
    if (!text) return '';
    return text
      .replace(/\*\*/g, '') // Remove markdown bolding
      .replace(/^Assistant:\s*/i, '') // Remove potential redundant prefixes
      .replace(/^Bot:\s*/i, '')
      .replace(/\n\n+/g, '\n') // Standardize line breaks
      .trim();
  };

  return (
    <div className="fixed bottom-6 right-6 z-[100]">
      {!isOpen ? (
        <button
          onClick={() => setIsOpen(true)}
          className="w-16 h-16 bg-blue-600 text-white rounded-full shadow-2xl flex items-center justify-center hover:scale-110 transition-all active:scale-95 group"
        >
          <svg className="w-8 h-8 group-hover:rotate-12 transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M8 10h.01M12 10h.01M16 10h.01M9 16H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-5l-5 5v-5z" />
          </svg>
        </button>
      ) : (
        <div className="w-96 h-[500px] bg-white rounded-3xl shadow-2xl border border-gray-100 flex flex-col overflow-hidden animate-in slide-in-from-bottom-4 duration-300">
          <div className="bg-blue-600 p-4 text-white flex justify-between items-center">
            <div className="flex items-center space-x-2">
              <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
              <span className="font-bold text-sm tracking-tight">EthAum AI Assistant</span>
            </div>
            <button onClick={() => setIsOpen(false)} className="hover:opacity-70">
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" /></svg>
            </button>
          </div>
          
          <div ref={scrollRef} className="flex-grow p-4 overflow-y-auto space-y-4 bg-gray-50/50">
            {messages.length === 0 && (
              <div className="text-center py-10 opacity-40 px-6">
                <p className="text-sm font-medium leading-relaxed">Ask me about startup ROI, market trends, or founder backgrounds.</p>
              </div>
            )}
            {messages.map((msg, i) => (
              <div key={i} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                <div className={`max-w-[85%] p-3.5 rounded-2xl text-sm leading-relaxed whitespace-pre-wrap ${
                  msg.role === 'user' 
                    ? 'bg-blue-600 text-white rounded-tr-none shadow-md shadow-blue-500/10' 
                    : 'bg-white text-gray-800 border border-gray-100 shadow-sm rounded-tl-none font-medium'
                }`}>
                  {msg.role === 'bot' ? formatBotText(msg.text) : msg.text}
                  {msg.role === 'bot' && msg.text && (
                    <button 
                      onClick={() => speak(msg.text, i)}
                      disabled={audioLoading !== null}
                      className={`ml-2 inline-flex items-baseline align-middle transition-opacity relative top-0.5 ${audioLoading !== null ? 'opacity-20 cursor-wait' : 'opacity-40 hover:opacity-100'}`}
                      title="Read response"
                    >
                      {audioLoading === i ? (
                        <div className="w-3 h-3 border-2 border-blue-600 border-t-transparent animate-spin rounded-full"></div>
                      ) : (
                        <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 20 20"><path d="M11 3a1 1 0 011 1v12a1 1 0 01-1 1l-5-5H3a1 1 0 01-1-1V7a1 1 0 011-1h3l5-5z"></path></svg>
                      )}
                    </button>
                  )}
                </div>
              </div>
            ))}
            {isLoading && (
              <div className="flex justify-start">
                <div className="bg-white p-3 rounded-2xl border border-gray-100 shadow-sm flex space-x-1 items-center">
                  <div className="w-1.5 h-1.5 bg-blue-300 rounded-full animate-bounce"></div>
                  <div className="w-1.5 h-1.5 bg-blue-300 rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></div>
                  <div className="w-1.5 h-1.5 bg-blue-300 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
                </div>
              </div>
            )}
          </div>

          <div className="p-4 border-t border-gray-100 bg-white">
            <div className="flex space-x-2">
              <input
                autoFocus
                type="text"
                placeholder="Message assistant..."
                className="flex-grow px-4 py-2 bg-gray-100 border-none rounded-xl text-sm outline-none focus:ring-2 focus:ring-blue-500/20 text-black transition-all"
                value={input}
                onKeyDown={e => e.key === 'Enter' && handleSend()}
                onChange={e => setInput(e.target.value)}
              />
              <button
                onClick={handleSend}
                disabled={isLoading || !input.trim()}
                className="bg-blue-600 text-white p-2.5 rounded-xl hover:bg-blue-700 disabled:bg-gray-200 disabled:shadow-none transition-all shadow-lg shadow-blue-500/20 active:scale-90"
              >
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8" /></svg>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default ChatBot;
