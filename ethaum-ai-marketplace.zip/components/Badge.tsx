
import React from 'react';
import { BadgeLevel } from '../types';

interface BadgeProps {
  level: BadgeLevel;
  score: number;
}

const Badge: React.FC<BadgeProps> = ({ level, score }) => {
  const colors = {
    [BadgeLevel.BRONZE]: 'bg-orange-100 text-orange-700 border-orange-200',
    [BadgeLevel.SILVER]: 'bg-gray-100 text-gray-700 border-gray-200',
    [BadgeLevel.GOLD]: 'bg-yellow-100 text-yellow-700 border-yellow-200',
  };

  const icons = {
    [BadgeLevel.BRONZE]: '🥉',
    [BadgeLevel.SILVER]: '🥈',
    [BadgeLevel.GOLD]: '🥇',
  };

  return (
    <div className={`inline-flex items-center px-3 py-1 rounded-full border text-xs font-semibold shadow-sm ${colors[level]}`}>
      <span className="mr-1.5">{icons[level]}</span>
      <span className="uppercase tracking-wider">{level} Verified</span>
      <span className="ml-2 border-l pl-2 opacity-60">Score: {score}</span>
    </div>
  );
};

export default Badge;
