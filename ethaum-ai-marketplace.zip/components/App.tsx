
import React from 'react';
import { HashRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import Navbar from './components/Navbar';
import Home from './pages/Home';
import LaunchStartup from './pages/LaunchStartup';
import StartupDetails from './pages/StartupDetails';
import EnterpriseMatch from './pages/EnterpriseMatch';
import Login from './pages/Login';
import ChatBot from './components/ChatBot';
import ProtectedRoute from './components/ProtectedRoute';

const App: React.FC = () => {
  return (
    <Router>
      <div className="min-h-screen flex flex-col relative overflow-hidden">
        {/* Background Blobs for Visual Interest */}
        <div className="fixed top-[-10%] left-[-10%] w-[40%] h-[40%] bg-blue-400/10 rounded-full blur-[120px] pointer-events-none animate-pulse"></div>
        <div className="fixed bottom-[-10%] right-[-10%] w-[35%] h-[35%] bg-indigo-400/10 rounded-full blur-[120px] pointer-events-none" style={{ animationDelay: '2s' }}></div>

        <Routes>
          {/* Public Route */}
          <Route path="/login" element={<Login />} />

          {/* Protected App Shell */}
          <Route path="/*" element={
            <ProtectedRoute>
              <>
                <Navbar />
                <main className="flex-grow relative z-10">
                  <Routes>
                    <Route path="/" element={<Home />} />
                    <Route path="/launch" element={<LaunchStartup />} />
                    <Route path="/startup/:id" element={<StartupDetails />} />
                    <Route path="/match" element={<EnterpriseMatch />} />
                    {/* Fallback to Home if authenticated but route doesn't exist */}
                    <Route path="*" element={<Navigate to="/" replace />} />
                  </Routes>
                </main>
                <ChatBot />
                <footer className="bg-white/40 backdrop-blur-md border-t border-white/20 py-12 relative z-10">
                  <div className="max-w-7xl mx-auto px-4 text-center">
                    <p className="text-xs text-gray-500 font-black uppercase tracking-[0.3em]">EthAum AI Marketplace © 2024</p>
                    <p className="mt-3 text-xs text-gray-400 font-medium">
                      Powered by Gemini-3 Intelligence • Verified by EthAum Framework
                    </p>
                  </div>
                </footer>
              </>
            </ProtectedRoute>
          } />
        </Routes>
      </div>
    </Router>
  );
};

export default App;
